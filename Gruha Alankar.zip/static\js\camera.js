document.addEventListener('DOMContentLoaded', () => {
    const video = document.getElementById('ar-camera');
    const placeholder = document.getElementById('camera-placeholder');
    const toggleBtn = document.getElementById('toggle-camera-btn');

    // We will need a hidden canvas to capture the image
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');

    let stream = null;
    let isCameraActive = false;

    // Optional: Add a capture button dynamically to the UI for taking photos
    const captureBtn = document.createElement('button');
    captureBtn.className = 'btn btn-primary';
    captureBtn.innerHTML = '<i class="fas fa-camera"></i> Capture Design';
    captureBtn.style.display = 'none'; // Hidden until camera is active

    // Insert capture button next to the toggle button
    const toolbar = toggleBtn.parentElement.nextElementSibling;
    toolbar.insertBefore(captureBtn, toolbar.firstChild);

    toggleBtn.addEventListener('click', async () => {
        if (!isCameraActive) {
            try {
                // Request camera access using MediaDevices API
                stream = await navigator.mediaDevices.getUserMedia({
                    video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
                    audio: false
                });

                // Show video, hide placeholder
                video.style.display = 'block';
                placeholder.style.display = 'none';
                captureBtn.style.display = 'inline-block';

                video.srcObject = stream;
                isCameraActive = true;

                // Update Button UI
                toggleBtn.innerHTML = '<i class="fas fa-stop-circle"></i> Stop Camera';
                toggleBtn.style.background = 'rgba(214, 48, 49, 0.7)'; // Red hue for stop
            } catch (err) {
                console.error("Error accessing the camera: ", err);

                // User-friendly error handling
                let errorMsg = "Could not access camera.";
                if (err.name === 'NotAllowedError') {
                    errorMsg = "Camera access was denied. Please grant permission in your browser settings.";
                } else if (err.name === 'NotFoundError') {
                    errorMsg = "No camera device was found on this device.";
                }

                alert(errorMsg);
            }
        } else {
            stopCamera();
        }
    });

    // Capture Image Function
    captureBtn.addEventListener('click', () => {
        if (!isCameraActive || !video.videoWidth) return;

        // Set canvas dimensions to match video stream
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;

        // Draw current video frame to canvas
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Convert canvas to blob
        canvas.toBlob((blob) => {
            if (blob) {
                uploadImage(blob);
            } else {
                alert("Failed to capture image. Please try again.");
            }
        }, 'image/jpeg', 0.9);
    });

    // Upload functionality
    async function uploadImage(imageBlob) {
        const formData = new FormData();
        formData.append('image', imageBlob, 'room_capture.jpg');

        // Add current selections for AI generation context
        // In a real scenario, you'd fetch these from the actual UI dropdowns/inputs
        formData.append('style', 'Modern Minimalist');
        formData.append('room_type', 'Living Room');

        // Visual feedback during upload
        const originalText = captureBtn.innerHTML;
        captureBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        captureBtn.disabled = true;

        try {
            const response = await fetch('/api/upload-design', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (response.ok) {
                alert("Design captured successfully! AI is analyzing your room.");
                console.log("Upload Success:", data);
                // Trigger any frontend UI updates like showing the generated image here
            } else {
                alert("Upload failed: " + (data.error || "Unknown error"));
            }
        } catch (error) {
            console.error("Error uploading image:", error);
            alert("Network error occurred while uploading. Please check your connection.");
        } finally {
            // Restore button state
            captureBtn.innerHTML = originalText;
            captureBtn.disabled = false;
        }
    }

    // Stop Camera Function
    function stopCamera() {
        if (stream) {
            // Properly release the video stream
            stream.getTracks().forEach(track => track.stop());
            stream = null;
        }

        isCameraActive = false;

        // Hide video, show placeholder
        video.style.display = 'none';
        placeholder.style.display = 'block';
        captureBtn.style.display = 'none';

        // Update Button UI
        toggleBtn.innerHTML = '<i class="fas fa-video"></i> Start Camera';
        toggleBtn.style.background = 'rgba(11, 10, 21, 0.7)';
    }

    // Ensure camera is stopped when navigating away from the page
    window.addEventListener('beforeunload', stopCamera);
});
