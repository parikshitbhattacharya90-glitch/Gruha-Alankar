import os
import json
import hashlib
from PIL import Image
import time
import uuid

class DesignCache:
    def __init__(self, cache_dir="cache"):
        self.cache_dir = cache_dir
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
            
    def get_cache_key(self, image_path, style_theme):
        """Create a hash based on the image content and style theme."""
        hasher = hashlib.md5()
        hasher.update(str(style_theme).encode('utf-8'))
        
        try:
            with open(image_path, 'rb') as f:
                # Read chunks to avoid memory issues with large files
                for chunk in iter(lambda: f.read(4096), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except FileNotFoundError:
            return None

    def get(self, key):
        if not key:
            return None
        cache_file = os.path.join(self.cache_dir, f"{key}.json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r') as f:
                    return json.load(f)
            except Exception:
                return None
        return None

    def set(self, key, data):
        if not key:
            return
        cache_file = os.path.join(self.cache_dir, f"{key}.json")
        try:
            with open(cache_file, 'w') as f:
                json.dump(data, f)
        except Exception as e:
            print(f"Error saving to cache: {e}")

class AIDesignGenerator:
    def __init__(self):
        self.cache = DesignCache(cache_dir=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'cache'))
        self._initialize_models()
        self.models_loaded = False
        
    def _initialize_models(self):
        """
        Mock initialization of transformers or LangChain pipelines.
        In a real scenario, you'd load HuggingFace pipelines here:
        e.g., pipeline("image-classification", model="google/vit-base-patch16-224")
        """
        print("Initializing AI models...")
        # Simulate model load time
        self.models_loaded = True
        
    def preprocess_image(self, image_path):
        """Prepare uploaded photos for model inference."""
        try:
            with Image.open(image_path) as img:
                # Convert to RGB, resize for standard vision model input (e.g., ViT)
                img = img.convert('RGB')
                img = img.resize((224, 224))
                # Return basic image info or the preprocessed array depending on the pipeline
                return {"size": img.size, "mode": img.mode, "status": "success"}
        except Exception as e:
            raise ValueError(f"Image preprocessing failed: {str(e)}")

    def generate_design(self, image_path, style_theme, room_type="Living Room"):
        """
        AI design generation function taking image path and style theme.
        Returns JSON containing furniture recommendations, color schemes, and placement.
        """
        print(f"Generating design for {room_type} in {style_theme} style...")
        
        # 1. Check Cache
        cache_key = self.cache.get_cache_key(image_path, style_theme)
        cached_result = self.cache.get(cache_key)
        if cached_result:
            print("Returning cached design result.")
            return cached_result

        # 2. Preprocess Image
        try:
            img_info = self.preprocess_image(image_path)
        except ValueError as e:
            return {"error": str(e), "status": "failed"}

        # 3. Model Inference (Mocked for demonstration, structurally ready for real models)
        try:
            if not self.models_loaded:
                raise RuntimeError("AI Models are not initialized or failed to load.")
                
            # Simulate inference delay for generative AI
            time.sleep(1.5)
            
            # Simulated generated output based on the style
            color_palettes = {
                "Modern Minimalist": ["#FFFFFF", "#000000", "#A9A9A9", "#F5F5F5"],
                "Scandinavian": ["#FFFFFF", "#E0DFD5", "#E4E3DB", "#C4C2B8"],
                "Industrial": ["#363636", "#8B4513", "#A9A9A9", "#2F4F4F"]
            }
            
            palette = color_palettes.get(style_theme, ["#FFFFFF", "#EAEAEA", "#CCCCCC"])
            
            result = {
                "id": str(uuid.uuid4()),
                "status": "success",
                "room_type": room_type,
                "style_theme": style_theme,
                "color_scheme": {
                    "primary": palette[0],
                    "secondary": palette[1],
                    "accent": palette[2],
                    "background": palette[3] if len(palette) > 3 else "#FFFFFF"
                },
                "furniture_recommendations": [
                    {
                        "name": f"{style_theme} {room_type} Sofa",
                        "category": "Seating",
                        "description": "A sleek, comfortable piece matching the room's aesthetic.",
                        "estimated_price": 899.99
                    },
                    {
                        "name": "Geometric Coffee Table",
                        "category": "Table",
                        "description": "Minimalist center table with clean lines.",
                        "estimated_price": 249.99
                    },
                    {
                        "name": "Ambient Floor Lamp",
                        "category": "Lighting",
                        "description": "Provides warm, diffused light to enhance the mood.",
                        "estimated_price": 129.50
                    }
                ],
                "placement_suggestions": [
                    "Place the main seating against the longest wall to maximize floor space.",
                    "Position the coffee table centrally, leaving at least 18 inches of clearance around it.",
                    "Place the floor lamp in the corner opposite to the natural light source."
                ]
            }

            # 4. Save to Cache
            self.cache.set(cache_key, result)
            
            return result

        except Exception as e:
            return {"error": f"AI Generation failed: {str(e)}", "status": "failed"}

# Setup singleton instance
ai_generator = AIDesignGenerator()
